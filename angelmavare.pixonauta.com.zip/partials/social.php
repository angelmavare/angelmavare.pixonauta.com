
    <li class="box-social"><a target="_blank" href="https://github.com/angelmavare" alt="Github" title="Github"><i class="fa-brands fa-github"></i></a></li>
    <li class="box-social"><a target="_blank" href="https://www.linkedin.com/in/angel-mavare-801b12104/" alt="Linkedin" title="Linkedin"><i class="fa-brands fa-linkedin-in"></i></a></li>
    <li class="box-social"><a target="_blank" href="https://twitter.com/angelmavare1" alt="Twitter" title="Twitter"><i class="fa-brands fa-twitter"></i></a></li>
    <li class="box-social"><a target="_blank" href="https://pixonauta.com/" alt="Blog" title="Blog"><i class="fa-solid fa-earth-americas"></i></a></li>
